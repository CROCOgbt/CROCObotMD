let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu anime'
let anu = `╭━━╼『 *M E N U  A N I M E* 』
┃ ▸ .amv (Ⓛ)
┃ ▸ .animelink (Ⓛ)
┃ ▸ .loli (Ⓛ)
┃ ▸ .animemiku (Ⓛ)
┃ ▸ .randomanime (Ⓛ)
┃ ▸ .urutannonton
┃ ▸ .avatar (Ⓛ)
┃ ▸ .charainfo
┃ ▸ .guardiantales (Ⓛ)
┃ ▸ .honkai (Ⓛ)
┃ ▸ .animeinfo <judul>
┃ ▸ .akira (Ⓛ)
┃ ▸ .akiyama (Ⓛ)
┃ ▸ .anna (Ⓛ)
┃ ▸ .asuna (Ⓛ)
┃ ▸ .ayuzawa (Ⓛ)
┃ ▸ .boruto (Ⓛ)
┃ ▸ .chitanda (Ⓛ)
┃ ▸ .chitoge (Ⓛ)
┃ ▸ .deidara (Ⓛ)
┃ ▸ .doraemon (Ⓛ)
┃ ▸ .elaina (Ⓛ)
┃ ▸ .emilia (Ⓛ)
┃ ▸ .asuna (Ⓛ)
┃ ▸ .erza (Ⓛ)
┃ ▸ .gremory (Ⓛ)
┃ ▸ .hestia (Ⓛ)
┃ ▸ .hinata (Ⓛ)
┃ ▸ .inori (Ⓛ)
┃ ▸ .itachi (Ⓛ)
┃ ▸ .isuzu (Ⓛ)
┃ ▸ .itori (Ⓛ)
┃ ▸ .kaga (Ⓛ)
┃ ▸ .kagura (Ⓛ)
┃ ▸ .kakasih (Ⓛ)
┃ ▸ .kaori (Ⓛ)
┃ ▸ .kaneki (Ⓛ)
┃ ▸ .kosaki (Ⓛ)
┃ ▸ .kotori (Ⓛ)
┃ ▸ .kuriyama (Ⓛ)
┃ ▸ .kuroha (Ⓛ)
┃ ▸ .kurumi (Ⓛ)
┃ ▸ .madara (Ⓛ)
┃ ▸ .mikasa (Ⓛ)
┃ ▸ .miku (Ⓛ)
┃ ▸ .minato (Ⓛ)
┃ ▸ .naruto (Ⓛ)
┃ ▸ .natsukawa (Ⓛ)
┃ ▸ .nekohime (Ⓛ)
┃ ▸ .nezuko (Ⓛ)
┃ ▸ .nishimiya (Ⓛ)
┃ ▸ .onepiece (Ⓛ)
┃ ▸ .pokemon (Ⓛ)
┃ ▸ .rem (Ⓛ)
┃ ▸ .rize (Ⓛ)
┃ ▸ .sagiri (Ⓛ)
┃ ▸ .sakura (Ⓛ)
┃ ▸ .sasuke (Ⓛ)
┃ ▸ .shina (Ⓛ)
┃ ▸ .shinka (Ⓛ)
┃ ▸ .shizuka (Ⓛ)
┃ ▸ .shota (Ⓛ)
┃ ▸ .tomori (Ⓛ)
┃ ▸ .toukachan (Ⓛ)
┃ ▸ .tsunade (Ⓛ)
┃ ▸ .yatogami (Ⓛ)
┃ ▸ .yuki (Ⓛ)
┃ ▸ .jjanime (Ⓛ)
┃ ▸ .komik (Ⓛ)
┃ ▸ .kusonime <pencarian>
┃ ▸ .kusonime <pencarian>
┃ ▸ .loliharam (Ⓛ)
┃ ▸ .milf
┃ ▸ .neko
┃ ▸ .nekopoisearch <text>
┃ ▸ .ongoing (Ⓛ)
┃ ▸ .raiden (Ⓛ)
┃ ▸ .stickanime  (Ⓟ)
┃ ▸ .animestick  (Ⓟ)
┃ ▸ .storyanime (Ⓛ)
┃ ▸ .kobo (Ⓛ)
┃ ▸ .waifu (Ⓛ)
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  A N I M E',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/6cdcb37a9ffce3bad3cce.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-anime']
handler.tags = ['menulist']
handler.command = /^(menu-anime)$/i

module.exports = handler