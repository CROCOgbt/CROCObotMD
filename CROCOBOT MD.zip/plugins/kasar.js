let handler = async (m, { conn, args }) => {
  // Menghitung waktu saat ini
  let uptime = process.uptime();
  
  // Mengubah waktu menjadi format yang lebih mudah dibaca
  let hours = Math.floor(uptime / 3600);
  let minutes = Math.floor((uptime % 3600) / 60);
  let seconds = Math.floor(uptime % 60);
  
  // Mengirim pesan dengan uptime
  conn.sendFile(m.chat, './mp3/kasar.mp3', '', null, m, true,)
}

handler.customPrefix = /^anj|bab|ngen|tolol|tlol|kontol|memek|pantek|kont|yatim|yapit|ngew|ngewe|goblok|gblk|goblk|tll|fuck|dick|colmek|clmk|jilmek|jilmk|cli|coli|ngocok|ngck|jancok|jnck$/i;
handler.command = new RegExp();

module.exports = handler