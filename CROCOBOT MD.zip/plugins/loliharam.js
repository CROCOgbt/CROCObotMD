let fetch = require('node-fetch')
let handler = async(m, { conn }) => {
  let res = 'https://api.botcahx.live/api/anime/nsfwloli?apikey=Lio'
  conn.sendFile(m.chat, res, '', '🔖 *FORNO BANGET JIR*', m)
}
handler.help = ['loliharam']
handler.tags = ['anime']
handler.command = /^(loliharam)$/i
handler.limit = true
module.exports = handler