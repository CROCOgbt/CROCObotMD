/*Sc Akiraa Bot By Bang syaii
*Whatsapp: wa.me/6283842839555
*Credit: © AkiraaBot 2023-2024
*/
const moment = require('moment');
const os = require('os');
const fetch = require('node-fetch')
const { performance } = require('perf_hooks');
const canvafy = require ('canvafy')
let handler = async m => {
  let wait = '*loanjing...*'
const arr = [
    { text: "*LOANJING...*", timeout: 100 },
    { text: "*LOANJING...*", timeout: 150 },
    { text: "*LOANJING...*", timeout: 200 },
    { text: "*LOANJING...*", timeout: 250 },
    { text: "*LOANJING...*", timeout: 300 },
    { text: "*LOANJING...*", timeout: 350 },
    { text: "*LOANJING...*", timeout: 400 },
    { text: "*LOANJING...*", timeout: 450 },
    { text: "*LOANJING...*", timeout: 500 },
    { text: "*LOANJING...*", timeout: 550 },
    { text: "*LOANJING...*", timeout: 600 },
    { text: "*CROCObot*", timeout: 650 },
    { text: `*ᴄᴏᴍᴩʟᴇᴛᴇ*`, timeout: 700 }
  ];

  const lll = await conn.sendMessage(m.chat, { text: wait }, { quoted: m });

  for (let i = 0; i < arr.length; i++) {
    await new Promise(resolve => setTimeout(resolve, arr[i].timeout));
    await conn.relayMessage(m.chat, {
      protocolMessage: {
        key: lll,
        type: 14,
        editedMessage: {
          conversation: arr[i].text
        }
      }
    }, {});
  }
  let krtu = `web`
  let name = await conn.getName(m.sender)
let pp = await conn.profilePictureUrl(m.sender, 'image').catch((_) => "https://telegra.ph/file/7f59829e67ab1e49cf0bb.jpg");
  // Menghitung waktu saat ini
  let time = moment().format('DD MMMM YYYY, HH:mm:ss');
  
  // Mengambil informasi server
  let serverInfo = `*CROCObot ⁻ ᴹᵈ* ᴊᴜɢᴀ ᴍᴇɴᴊᴀɢᴀ ᴘʀɪᴠᴀꜱɪ ᴘᴇɴɢɢᴜɴᴀ ᴅᴇɴɢᴀɴ ᴍᴇɴɢʜᴀɴᴄᴜʀᴋᴀɴ ᴅᴀᴛᴀ ʏᴀɴɢ ᴅɪꜱɪᴍᴘᴀɴ ꜱᴇᴛɪᴀᴘ ᴍɪɴɢɢᴜ, ᴍᴇᴍᴀꜱᴛɪᴋᴀɴ ᴅᴀᴛᴀ ᴀɴᴅᴀ ᴛᴇᴛᴀᴘ ᴀᴍᴀɴ ᴅᴀɴ ᴘʀɪʙᴀᴅɪ.`;

  // Menghitung runtime
  let start = performance.now();
  // Kode yang ingin dihitung runtime-nya
  let end = performance.now();
  let runtime = (end - start).toFixed(2); conn.sendPresenceUpdate('composing',m.chat)
  let text = `
*ʜᴀʟʟᴏ ᴋᴀᴋ👋.* ɴᴀᴍᴀ ꜱᴀyᴀ ᴀᴅᴀʟᴀʜ CROCObot

ʙᴏᴛ ɪɴɪ ᴅᴀᴘᴀᴛ ᴅɪɢᴜɴᴀᴋᴀɴ sᴇʙᴀɢᴀɪ *ᴇᴅᴜᴋᴀsɪ ᴘᴇʟᴀᴊᴀʀᴀɴ*, *ᴜɴᴅᴜʜᴀɴ ᴍᴇᴅɪᴀ*, *ɢᴀᴍᴇ*, *ᴘᴇɴᴊᴀɢᴀ ɢʀᴜᴘ*, *ᴅᴀɴ ʟᴀɪɴɴʏᴀ* ʏᴀɴɢ ᴅᴀᴘᴀᴛ ᴍᴇᴍʙᴜᴀᴛ ᴋᴀᴍᴜ ʟᴇʙɪʜ ᴍᴜᴅᴀʜ ᴜɴᴛᴜᴋ ᴍᴇɴᴊᴀʟᴀɴɪ ʜᴀʀɪ-ʜᴀʀɪ:>

╭  ◦ ᴄʀᴇᴀᴛᴏʀ: *CROCObot*
│  ◦ ʏᴏᴜᴛᴜʙᴇ: *anonimus*
╰  ◦ ᴘʀᴇғɪx: *.*

ᴊɪᴋᴀ ᴀᴅᴀ ᴍᴀsᴀʟᴀʜ ᴅᴀʟᴀᴍ ᴘᴇɴɢɢᴜɴᴀᴀɴ sɪʟᴀʜᴋᴀɴ ʜᴜʙᴜɴɢɪ ᴄʀᴇᴀᴛᴏʀ ᴜɴᴛᴜᴋ ᴍᴇɴᴀɴʏᴀᴋᴀɴ *.ᴏᴡɴᴇʀ*

┌ ◦ ᴍᴇɴᴀᴍᴘɪʟᴋᴀɴ ғɪᴛᴜʀ ʙᴏᴛ: *.ᴀʟʟᴍᴇɴᴜ*
└ ◦ ᴍᴇɴᴀᴍᴘɪʟᴋᴀɴ ᴍᴇɴᴜʟɪꜱᴛ : *.ᴍᴇɴᴜʟɪꜱᴛ*

ʜᴀʀᴀᴘ ᴜɴᴛᴜᴋ ʙᴇʀɢᴀʙᴜɴɢ ɢʀᴏᴜᴘ ʙᴏᴛ ᴀɢᴀʀ ᴍᴇɴɢᴇᴛᴀʜᴜɪ ɪɴғᴏʀᴍᴀsɪ ʙᴏᴛ ᴊɪᴋᴀ *ᴇʀʀᴏʀ/ʙᴀɴɴᴇᴅ*`;

  const fkontak = {
    "key": {
      "fromMe": false,
      "participant": "0@s.whatsapp.net",
      "remoteJid": "status@broadcast",
      "id": "Halo"
    },
    "message": {
      "contactMessage": {
        "displayName": "Sy",
        "vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
      }
    }
  };
let p = await new canvafy.Security()
. setAvatar (pp)
. setBackground ("color","#FFDF00")
. setLocale ("id")
. setOverlayOpacity (1.0)
. setAvatarBorder ("#fff")
   .setCreatedTimestamp(Date.now())
        .setSuspectTimestamp(1)
.build()
conn.sendFile(m.chat, p, '', text, m, null, {
  fileLength: '450000000000000000',
  contextInfo: {
    externalAdReply: {
      showAdAttribution: true,
      mediaType: 1,
      description: wm,
      title: `WOII ${name}`,
      body: wm2,
renderLargerThumbnail: true,
      thumbnail: await (await fetch (`https://telegra.ph/file/7f59829e67ab1e49cf0bb.jpg`)).buffer(),
      sourceUrl: sig
    }
  }
})
 conn.sendFile(m.chat, './mp3/menuu.mp3', '', null, m, true,)
if (/^(allmenu)/i.test(m.text)) {
        m.reply(wait)

      }
}

handler.help = ['menu']
handler.tags = ['main']
handler.command = /^(menu)$/i
handler.limit = true
handler.register = true
module.exports = handler

//The Best Rpg Bot