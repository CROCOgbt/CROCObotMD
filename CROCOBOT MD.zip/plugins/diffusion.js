const axios = require("axios")

const handler = async (m, { conn, usedPrefix, command, args }) => {
const response = args.join(' ').split('|')
if (!args[0]) throw 'Masukan Promptnya Dan Negative Promptnya Kak\n\nExample: .diff asuna, (sword art online), highly detailed|(worst quality, low quality, extra hand), monochrome'
m.reply(wait)
const payloads = {
	prompt: `${response[0]}`,
  negative_prompt: null,
  sampler: "Euler",
  seed:  19393939,
  ratio: "9:16",
  style: "ACG",
  url: false,
  cfg: 7.5,
  controlNe: "none",
  image_num: 1,
  steps: 25
}
  const { data } = await axios.post("https://api.itsrose.life/image/diffusion", payloads, {
      params: {
        apikey: `${global.rose}`,
      },
      })
	.catch((e) => e?.["response"]);
const { status, message } = data; 

if (!status) {
	return m.reply(message);
}
const { result } = data;
console.log(result);
conn.sendMessage(m.chat, { image: { url: result.images[0] }, caption: `Prompt: ${response[0]}`}, m)
}
handler.help = ['diff1','diffusion1','animedif1']
handler.tags = ['ai']
handler.command = /^(diff1|diffussion1|animediff1)$/i
handler.limit = true
handler.premium = true
module.exports = handler