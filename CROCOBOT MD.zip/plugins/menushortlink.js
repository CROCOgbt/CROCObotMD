let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu shortlink'
let anu = `╭━━╼『 *M E N U  S H O R T L I N K* 』
┃ ▸ .bitly <link>
┃ ▸ .cuttly <link>
┃ ▸ .tinyurl <link>
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  S H O R T L I N K',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/a9430e3129e4aa039af63.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-shortlink']
handler.tags = ['menulist']
handler.command = /^(menu-shortlink)$/i

module.exports = handler