const { MessageType } = require('@adiwajshing/baileys');

// Fungsi bantu untuk menghasilkan nomor acak antara min dan max
function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Fungsi untuk menghitung waktu dalam format jam:menit:detik
function formatTime(ms) {
    const jam = Math.floor(ms / 3600000);
    const menit = Math.floor((ms % 3600000) / 60000);
    const detik = Math.floor(((ms % 3600000) % 60000) / 1000);
    return `${jam}:${menit}:${detik}`;
}

// Level dungeon, monster, dan rintangan
const levelDungeon = [
    {
        level: 1,
        monster: ['Goblin', 'Slime'],
        rintangan: ['Jebakan Lubang', 'Gas Beracun']
    },
    {
        level: 2,
        monster: ['Orc', 'Skeleton'],
        rintangan: ['Batu Besar', 'Sihir Gelap']
    },
    {
        level: 3,
        monster: ['Naga', 'Wyvern'],
        rintangan: ['Lubang Lava', 'Rintangan Es']
    },
    {
        level: 4,
        monster: ['Vampire', 'Mummy'],
        rintangan: ['Rintangan Api', 'Batu Bergelombang']
    },
    {
        level: 5,
        monster: ['Dragon', 'Minotaur'],
        rintangan: ['Jurang Dalam', 'Sihir Kehancuran']
    },
    {
        level: 6,
        monster: ['Phoenix', 'Kraken'],
        rintangan: ['Batu Beracun', 'Pemutar Balik Waktu']
    },
    {
        level: 7,
        monster: ['Demon Lord', 'Archangel'],
        rintangan: ['Kuburan Kuno', 'Lautan Api']
    },
    {
        level: 8,
        monster: ['God of Chaos', 'Titan'],
        rintangan: ['Gerbang Dimensi', 'Pertempuran Terakhir']
    },
    {
        level: 9,
        monster: ['Elder Dragon', 'Celestial Being'],
        rintangan: ['Nebula Hitam', 'Kematian Abadi']
    },
    {
        level: 10,
        monster: ['Raja Iblis', 'Dewa'],
        rintangan: ['Pintu Kebangkitan', 'Akhir Segalanya']
    }
];

// Teks panjang yang akan ditambahkan ke pesan dungeon
const teksPanjang = `Selamat! Anda telah menyelesaikan level dungeon ini. Anda mengalahkan monster-monster yang kuat dan berhasil melewati rintangan yang berbahaya. Pengalaman Anda semakin bertambah, dan Anda semakin mendekati tujuan Anda untuk menjadi Raja Iblis terkuat di dunia Isekai ini. Teruskan perjalanan Anda dan hadapi tantangan berikutnya!`;

// Data terakhir menjelajahi dungeon
const lastDungeonData = {};

const dungeonRPG = async (m, { conn }) => {
    const user = global.db.data.users[m.sender];

    // Periksa apakah pengguna memiliki cukup energi untuk menjelajahi dungeon
    if (user.energy < 10) {
        return conn.reply(m.chat, "Energi Anda habis! Silakan istirahat sejenak.", m);
    }

    // Kurangkan 10 energi untuk menjelajahi dungeon
    user.energy -= 10;

    // Pilih level dungeon secara acak
    const indeksLevel = getRandomInt(0, levelDungeon.length - 1);
    const levelDipilih = levelDungeon[indeksLevel];

    // Pilih monster secara acak dari level tersebut
    const indeksMonster = getRandomInt(0, levelDipilih.monster.length - 1);
    const monsterDipilih = levelDipilih.monster[indeksMonster];

    // Pilih rintangan secara acak dari level tersebut
    const indeksRintangan = getRandomInt(0, levelDipilih.rintangan.length - 1);
    const rintanganDipilih = levelDipilih.rintangan[indeksRintangan];

    let pesan = "";

    // Jika pengguna berhasil menjelajahi dungeon, mereka akan mendapatkan pengalaman (exp)
    if (getRandomInt(1, 100) <= 70) {
        let exp = getRandomInt(50, 200); // Exp awal

        // Jika ini adalah akhir level, gandakan pengalaman (exp) 20x lipat
        if (indeksLevel === levelDungeon.length - 1) {
            exp *= 20;
        }

        user.exp += exp;

        pesan = `Selamat! Anda berhasil menjelajahi dungeon level ${levelDipilih.level} dan mengalahkan ${monsterDipilih}. Anda juga berhasil mengatasi rintangan ${rintanganDipilih}.\nAnda mendapatkan ${exp} pengalaman (exp) sebagai hadiah.\n\n${teksPanjang}`;

        // Simpan data terakhir menjelajahi dungeon
        lastDungeonData[m.sender] = {
            level: levelDipilih.level,
            monster: monsterDipilih,
            rintangan: rintanganDipilih,
            exp: exp
        };
    } else {
        const denda = getRandomInt(20, 100); // Denda dalam koin
        user.exp -= denda;

        pesan = `Sayangnya, Anda tersesat dalam dungeon level ${levelDipilih.level} dan harus membayar denda sebesar ${denda} pengalaman (exp) untuk keluar.\n\n${teksPanjang}`;
    }

    const sisaEnergi = formatTime(user.energyCooldown);

    conn.reply(m.chat, pesan + `\nEnergi Anda sekarang: ${user.energy}\nCooldown Energi: ${sisaEnergi}`, m);
};

dungeonRPG.getLastDungeonData = (userId) => {
    return lastDungeonData[userId];
};

dungeonRPG.help = ['dungeon'];
dungeonRPG.tags = ['rpg'];
dungeonRPG.command = /^dungeon$/i;
dungeonRPG.register = true;

module.exports = dungeonRPG;