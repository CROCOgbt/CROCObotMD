var fetch = require("node-fetch");
let handler = async (m, { 
conn, 
args 
}) => {
   response = args.join(' ').split('|')
  if (!args[0]) throw 'Masukkan Text\nContoh : .nekosad BANGSYAIi|SAD'
  var tio = `https://api.caliph.biz.id/api/sadboy?nama=${response[0]}&nama2=${response[1]}&apikey=caliphkey`
  m.reply(wait)
  conn.sendFile(m.chat, tio, 'loliiiii.jpg', wm, m, false)
};
handler.command = handler.help = ['nekosad'];
handler.tags = ['maker'];
module.exports = handler;