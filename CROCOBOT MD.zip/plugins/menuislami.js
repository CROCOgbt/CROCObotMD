let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu islami'
let anu = `╭━━╼『 *M E N U  I S L A M I* 』
┃ ▸ .alfatihah
┃ ▸ .audiosurah (Ⓛ)
┃ ▸ .asmaulhusna (Ⓛ)
┃ ▸ .hukumpacaran
┃ ▸ .jadwalsholat (Ⓛ)
┃ ▸ .niatshalat (Ⓛ)
┃ ▸ .quotesislami (Ⓛ)
┃ ▸ .kisahnabi <name> (Ⓛ)
┃ ▸ .murothal
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  I S L A M I',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/7ee34d215b271d672c6d1.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-islami']
handler.tags = ['menulist']
handler.command = /^(menu-islami)$/i

module.exports = handler