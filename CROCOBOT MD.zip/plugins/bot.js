let fetch = require ('node-fetch')
let handler = async (m, { conn }) => {
    let wm = global.wm
    let _uptime = process.uptime() * 1000
    let uptimex = clockString(_uptime)
    let name = conn.getName(m.sender)
    let pp =  await conn.profilePictureUrl(m.sender, 'image').catch((_) => "https://telegra.ph/file/191255466221149ca48d0.jpg");
    let poto = 'https://telegra.ph/file/191255466221149ca48d0.jpg'
    let tio = ` Hai *${name}*
 STATUS BOT ONLINE✅
Uptime: _*${uptimex}*_

"${pickRandomMotivasi()}"
    `.trim()
    conn.sendFile(m.chat, poto, '', tio, m, null, {
  fileLength: '450000000000000000',
  contextInfo: {
    externalAdReply: {
      showAdAttribution: true,
      mediaUrl: sgc,
      mediaType: 2,
      description: wm,
      title: wm2,
      body: wm2,
      thumbnail: await (await fetch (pp)).buffer(),
      sourceUrl: sgc
    }
  }
})             
}

handler.tags = ['main']
handler.customPrefix = /^(test|tes|bot)$/i 
handler.command = new RegExp
handler.limit = false
handler.wip = true
module.exports = handler

function clockString(ms) {
    let days = Math.floor(ms / (24 * 60 * 60 * 1000));
    let daysms = ms % (24 * 60 * 60 * 1000);
    let hours = Math.floor((daysms) / (60 * 60 * 1000));
    let hoursms = ms % (60 * 60 * 1000);
    let minutes = Math.floor((hoursms) / (60 * 1000));
    let minutesms = ms % (60 * 1000);
    let sec = Math.floor((minutesms) / (1000));
    return days + " Hari " + hours + " Jam " + minutes + " Menit " + sec + " Detik";
}

function pickRandomMotivasi() {
    let motivasi = [
        "Jangan pernah menyerah!",
        "Setiap kegagalan adalah peluang untuk belajar.",
        "Pikirkan positif, dan hal positif akan terjadi.",
        "Tetaplah bersemangat dan terus berjuang!",
        "Kamu lebih kuat daripada yang kamu pikirkan.",
        "Tetaplah fokus pada tujuanmu.",
        "Jangan biarkan keraguan menghalangi impianmu."
    ];
    return motivasi[Math.floor(Math.random() * motivasi.length)];
}