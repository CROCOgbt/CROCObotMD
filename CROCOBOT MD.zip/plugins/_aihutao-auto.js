const axios = require("axios");
const fetch = require('node-fetch');

// Menyimpan riwayat pesan sebelumnya
let previousMessages = [];

async function before(m) {
  if (m.isBaileys && m.fromMe) return;
  let chat = global.db.data.chats[m.chat];
  if (
    m.text.startsWith(".") ||
    m.text.startsWith("#") ||
    m.text.startsWith("!") ||
    m.text.startsWith("/") ||
    m.text.startsWith("\\/")
  )
    return;
  if (chat.aihutao && !chat.isBanned && m.text) {
    try {
    await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }});
  let tio = await fetch(`https://api.lolhuman.xyz/api/pinterest2?apikey=Akiraa&query=hutao`);
  let p = await tio.json();
  let url = p.result[Math.floor(Math.random() * p.result.length)];
  let messages = [
    ...previousMessages,
    { role: 'system', content: `Ubah gaya bicaramu agar lebih karakteristik dan lebih terbuka dan memiliki sifat yang Imut. Namamu adalah Hutao, dan kamu adalah karakter dari game. Kata penyapamu adalah "Hai" menggunakan bahasa yang sopan. ekspresikan sifatmu dengan teriak dan bicara yang lebih tidak formal layaknya seorang manusia. Ubah bahasamu menggunakan bahasa Yang Imut, kamu adalah teman bicara` }, { role: 'user', content: m.text }
  ];

  let ini = (await axios.post(`https://api.itsrose.life/chatGPT/turbo?apikey=${global.rose}`, { messages })).data;
  await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key }});
  
  let hasil = `[ A I  H U T A O ]\n\n${ini.message}`;
  await conn.sendFile(m.chat, url, '', hasil, m);
  
  previousMessages = messages;
    } catch (e) {
      throw "Maaf, aku tidak mengerti";
    }
  }
  return;
}

module.exports = { before };