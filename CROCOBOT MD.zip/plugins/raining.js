var fetch = require("node-fetch");
let handler = async (m, { 
conn, 
text 
}) => {
  if (!text) throw 'Masukkan Text\nContoh : .raining AKIRAA'
  var tio = `https://api.lolhuman.xyz/api/ephoto1/wetglass?apikey=Akiraa&text=${text}`
  conn.sendFile(m.chat, tio, 'loliiiii.jpg', wm, m, false)
};
handler.command = handler.help = ['raining'];
handler.tags = ['maker'];
module.exports = handler;