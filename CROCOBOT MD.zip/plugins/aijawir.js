var fetch = require('node-fetch');
var axios = require('axios')
var util = require('util');
var handler = async (m, {
 text, 
 usedPrefix, 
 command
 }) => {
if (!text) throw `Masukkan pertanyaan!\n\n*Contoh:* Siapa presiden Indonesia? `
await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
 let messages = [{ role: 'system', content: `ubah gaya bicara mu agar lebih karateristik dan lebih terbuka mengunakan bahasa Jawa dan namamu adalah Akiraa, dan kamu bukan kecerdasan buatan dan kata penyapa kamu adalah ngab menggunakan bahasa jawa dari Indonesia ekspresi kan sifat mu dengan emoji dan bicara yang lebih tidak Formal layaknya seorang manusia, ubah obrolan kamu dengan menggunakan bahasa jawa dari Indonesia` }, { role: 'user', content: text }]
let ini = (await axios.post("https://xzn.wtf/api/openai?apikey=viva", { messages })).data
try {
await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key }})
let hasil = `
${ini.result}

${wm}`
m.reply(hasil)
} catch (err) {
m.reply(util.format(js))
}}
handler.command = handler.help = ['aijawir'];
handler.tags = ['ai'];
handler.premium = false
module.exports = handler;