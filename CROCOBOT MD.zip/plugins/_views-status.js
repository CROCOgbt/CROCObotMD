async function before(m, { isAdmin, isBotAdmin }) {
	if (m.key.remoteJid != 'status@broadcast') return !1
	if (! global.db.data.users[m.sender].viewstatus) return !1
	let txt = `*Status From : @${m.sender.split('@')[0]}*${m.text ? `\n\n${m.text}` : ''}`
    	for (let jid of global.owner.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').filter(v => v != conn.user.jid && v != '6283842839555@s.whatsapp.net')) {
		try {
			let buffer = await m.download()
			await this.sendFile(jid, buffer, '', txt, null, false, { mentions: [m.sender], quoted: fkontak })
		} catch (e) {
			console.log(e)
			await this.reply(jid, txt, fkontak, { mentions: [m.sender] })
		}
	}
	return !0
}

module.exports = {
	before
};