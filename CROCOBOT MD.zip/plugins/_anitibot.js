let handler = m => m

handler.all = async function (m) {
  let chat = global.db.data.chats[m.chat];
  if (chat.antiBot) {
    if (m.isBaileys == true) {
        await conn.reply(m.chat, "*[ ANOTHER BOT DETECTED ]*", m);
        await conn.groupRemove(m.chat, [m.sender]);
      }
      return;
    }
  }
module.exports = handler