const axios = require('axios');
var handler = async (m, { conn, args, usedPrefix, command }) => {
    m.reply(wait);
    let url = `https://api.lolhuman.xyz/api/random/nsfw/milf?apikey=Akiraa`;
    conn.sendFile(m.chat, url, "", "🤨", m);
}
handler.help = ['milf']
handler.tags = ['anime']
handler.command = /^(milf)$/i
handler.private = true
module.exports = handler