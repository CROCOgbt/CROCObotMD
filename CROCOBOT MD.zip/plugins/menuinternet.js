let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu internet'
let anu = `╭━━╼『 *M E N U  I N T E R N E T* 』
┃ ▸ .bahasapurba
┃ ▸ .bkpindo <query>  (Ⓟ)
┃ ▸ .bkpsearch <query>  (Ⓟ)
┃ ▸ .cecanrandom
┃ ▸ .cecanukhty
┃ ▸ .cerpen
┃ ▸ .darkjoke (Ⓛ)
┃ ▸ .fetch <url>
┃ ▸ .get <url>
┃ ▸ .google <pencarian>
┃ ▸ .googlef <pencarian>
┃ ▸ .Henzz
┃ ▸ .amuraa
┃ ▸ .armpits
┃ ▸ .gimage *query* (Ⓛ)
┃ ▸ .kbbi <teks> (Ⓛ)
┃ ▸ .proxy <link>
┃ ▸ .puisi (Ⓛ)
┃ ▸ .film <text>
┃ ▸ .vectorstock
┃ ▸ .alkitab <pencarian>
┃ ▸ .chord <judul lagu> (Ⓛ)
┃ ▸ .donghuaurl (Ⓛ)
┃ ▸ .donghuasearch (Ⓛ)
┃ ▸ .google <pencarian>
┃ ▸ .googlef <pencarian>
┃ ▸ .kodebahasa
┃ ▸ .lirik <Apa>
┃ ▸ .jarak
┃ ▸ .jkt48 <pencarian> <jumlah Opsional>
┃ ▸ .katabijak <opsi>
┃ ▸ .coffee
┃ ▸ .kopi
┃ ▸ .lk21
┃ ▸ .midjourney
┃ ▸ .myip (Ⓛ)
┃ ▸ .nulis (Ⓛ)
┃ ▸ .pinterest <keyword>
┃ ▸ .pixiv
┃ ▸ .ppcp
┃ ▸ .pinterest <pencarian> <jumlah>
┃ ▸ .spesifikasi
┃ ▸ .spesifikasi
┃ ▸ .sjawir (Ⓛ)
┃ ▸ .storyanime (Ⓛ)
┃ ▸ .short <url> <type>
┃ ▸ .tts
┃ ▸ .zodiac *2002 02 25*
┃ ▸ .txt2img (Ⓛ)
┃ ▸ .voicevox (Ⓛ)
┃ ▸ .wattpad (Ⓛ) (Ⓟ)
┃ ▸ .xnxx4  (Ⓟ)
┃ ▸ .yts <pencarian>
┃ ▸ .ytsearch <pencarian>
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  I N T E R N E T',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/68636709669ad89f5a49c.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-internet']
handler.tags = ['menulist']
handler.command = /^(menu-internet)$/i

module.exports = handler