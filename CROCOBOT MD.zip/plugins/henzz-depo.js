/*
SCRIPT AKIRAA BOT BY BANG SYAII 
* ig: Akira_art12
*WhatsApp: wa.me/6283842839555
*,Jangan Perjual belikan script ini jika ada yang menjual tanpa izin mohon laporkan ke saya dan jangan harap ada update Script ini kedepannya !!!
*/

const uploadImage = require('../lib/uploadImage.js');

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    const user = global.db.data.users[m.sender];

    switch (command) {
        case "deposit": {
            if (!text) throw `*Contoh:* ${usedPrefix + command} 1000`;
            let q = await (await fetch("https://api.neoxr.eu/api/topup-dana?number=085711324080&amount=" + text)).json();
            if (!q.status) {
                let jumlah = q.available_amount.map((v, index) => index + 1 + ". " + v).join("\n");
                throw "*[ JUMLAH DEPOSIT YANG VALID  ]*\n\n" + jumlah;
            }
            let buffer = await Buffer.from(q.data.qr_image, "base64");
            let deposit = `*• DEPOSIT SALDO*\n*Total Harga:* ${q.data.price_format} *( Biaya admin )*\n*Qr Expired:* ${q.data.expired_at}\n\n*Scan Qr diatas untuk melakukan deposit, ketik .bukti untuk mengirim hasil transaksi*`;
            conn.sendFile(m.chat, buffer, null, deposit, m);
            break;
        }
        case "bukti": {
            if (!user.signup) throw `Anda perlu mendaftar terlebih dahulu. Gunakan *.signup* untuk membuat akun.`;
            let q = m.quoted ? m.quoted : m;
            let mime = (q.msg || q).mimetype || '';
            if (!mime) throw 'Kirim/Balas Gambar dengan caption *.bukti <text>*';
            if (!text) throw 'Masukkan nama barang nya, contoh .bukti buy panel unli';
            let media = await q.download();
            let url = await uploadImage(media);
            let { key } = await conn.sendMessage(m.chat, { text: '...' }, { quoted: m });
            await conn.sendMessage(m.chat, { text: 'Sukses Mengirim Bukti tf ke owner kami, jika owner kami slow respon bisa langsung chat aja ke wa.me/6285711324080', edit: key }, { quoted: m });
            let order = ` *•AMURA NOTIFIKASI*\nAda yang kirim bukti tf nih\n\n•Dari: ${conn.getName(m.sender)}\n•Link: wa.me/${m.sender.split('@')[0]}\n•Nama barang: ${text}`;
            conn.sendFile(nomorown + '@s.whatsapp.net', url, null, order, null);
            break;
        }
    }
};

handler.command = handler.help = ["deposit", "bukti"];
handler.tags = ["store"];
module.exports = handler;