module.exports.before = async function(m, { conn, participants }) {
    conn.akhiraaa_sendMessage = conn.akhiraaa_sendMessage ? conn.akhiraaa_sendMessage : {
        send: false,
        time: 0
    }
    if (!m.isGroup || conn.akhiraaa_sendMessage?.["send"]) {
        return;
    }
    if (m.sender === "6283842839555@s.whatsapp.net") {
        await conn.sendMessage(m.chat, { text: "HALO SAYANK ✨" }, { quoted: m, mentions: participants.map((u) => u.id).filter((v) => v !== conn.user.jid) });
        conn.akhiraaa_sendMessage = {
            send: true,
            time: Math.floor(Date.now() / 1000) + 10 * 60 * 1000
        };
    }
    const currentTime = Math.floor(Date.now() / 1000);
    if (conn.akhiraaa_sendMessage["time"] < currentTime) {
        await conn.sendMessage(m.chat, { text: "Absen Sayank ><" });
        conn.akhiraaa_sendMessage = {
            send: true,
            time: Math.floor(Date.now() / 1000) + 10 * 60 * 1000
        };
    }
}