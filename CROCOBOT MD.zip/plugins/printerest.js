let fetch = require('node-fetch');

let handler = async (m, { conn, usedPrefix, text, args, command }) => {
  if (!args || args.length < 1) {
    throw `Masukkan Pencarian!!\ncontoh: ${usedPrefix + command} Miku Nakano`;
  }

  let response = args.join(' ').split('|');
  let query = response[0];
  let count = parseInt(response[1]);

  if (!count) {
    try {
      var tio = await fetch(`https://xzn.wtf/api/pinterest?search=${query}&apikey=viva`);
      var p = await tio.json();
      let url = p.media.url[Math.floor(Math.random() * p.media.url.length)];
      conn.sendFile(m.chat, url, 'loliiiii.jpg', `_*P I N T E R E S T*_\n🔖 Hasil pencarian dari: *${query}*\n___________________\n ${botdate}`, m);
    } catch (error) {
      console.log(error);
      conn.reply(m.chat, 'Terjadi kesalahan saat menjalankan perintah.', m);
    }
  } else {
    if (count > 10) {
      throw 'Jumlah gambar terlalu banyak! Maksimal 10 gambar.';
    }
    try {
      let url = `https://xzn.wtf/api/pinterest?search=${query}&apikey=viva`;
      let res = await fetch(url);
      let data = await res.json();
  
      let images = data.media.url;
  
      for (let i = 0; i < count; i++) {
        let image = images[Math.floor(Math.random() * images.length)];
        setTimeout(() => {
          conn.sendFile(m.chat, image, '', `_*P I N T E R E S T*_\n🔖 Hasil pencarian dari: *${query}* Gambar Ke ${i+1}\n___________________\n ${botdate}`, m);
        }, i * 5000); // Delay setiap pengiriman gambar selama 5 detik (5000 milidetik)
      }
    } catch (error) {
      console.log(error);
      conn.reply(m.chat, 'Terjadi kesalahan saat menjalankan perintah.', m);
    }
  }
};

handler.help = ['pinterest <pencarian> <jumlah>'];
handler.tags = ['tools','internet'];
handler.command = /^(pinterest|pin)$/i;

module.exports = handler;

//Dibuat oleh Bang Syaii