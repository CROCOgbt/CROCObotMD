/* 
Script By Henzz XD
  • YT: HenzzXD1
  • IG: henzz4368
Buy Script? 
  • WA: +62 857-1132-4080
  • TELE: t.me/henzz
  • Github: github.com/henzz4368
*/

let fetch = require('node-fetch')

let handler = async (m, { text }) => {
  let msg = text.trim()
  if (!msg) return m.reply('*Example*: .proxy Henzz.me')

	conn.chatRead(m.chat)
	conn.sendMessage(m.chat, {
		react: {
			text: '🕒',
			key: m.key,
		}
	})
  let res = await fetch(`https://api.lolhuman.xyz/api/proxysite?apikey=Akiraa&url=${encodeURIComponent(msg)}`)
  let json = await res.json()

  if (json.status == 200 && json.result) {
    m.reply(json.result)
  } else {
    m.reply('Gagal membuat proxy pada tautan yang diberikan.')
  }
}

handler.help = ['proxy <link>']
handler.tags = ['internet']
handler.command = /^proxy$/i

module.exports = handler