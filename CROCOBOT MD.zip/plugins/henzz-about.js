/* 
Script By Tataa Dev XD
  • YT: Tataa Dev1
  • IG: henzz4368
Buy Script? 
  • WA: +62 857-1132-4080
  • TELE: t.me/henzz
  • Github: github.com/henzz4368
*/


let handler = async (m, { conn }) => {
  let aboutID = `*Tataa adalah* bot WhatsApp yang cerdas dan sangat berguna untuk membantu Anda dalam menjawab pertanyaan dan memberikan solusi yang tepat dalam waktu yang singkat. Dikembangkan oleh *Tataa Dev [ Tataa Dev ]* , bot ini menggunakan sumber asli base Botcahx yang terus diperbarui oleh *Tataa Dev* untuk memberikan pengalaman berinteraksi yang lebih mudah dan menyenangkan.

Dengan kemampuannya yang luas dalam menjawab pertanyaan dan memberikan solusi, *Tataa Bot* dapat membantu Anda dalam berbagai hal seperti, mencari informasi tentang produk atau layanan, mengatur jadwal, dan banyak lagi. *Tataa Bot* juga dapat memberikan jawaban yang akurat dan cepat sehingga Anda tidak perlu lagi menunggu lama untuk mendapatkan jawaban yang Anda butuhkan.

Sebagai produk yang dikembangkan dan diperbarui oleh *Tataa Dev, Tataa Bot* selalu menerima pembaruan fitur-fitur terbaru untuk memberikan layanan yang semakin baik dan canggih. Dengan *Tataa Bot* , Anda tidak perlu khawatir tentang kualitas layanan yang diberikan karena bot ini selalu siap memberikan solusi yang terbaik bagi pengguna WhatsApp. Jadi, tunggu apa lagi? Gunakan *Tataa Bot* sekarang dan nikmati kemudahan serta kenyamanan dalam berinteraksi dengan bot cerdas ini di WhatsApp!`

  let aboutEN = `*Tataa MD* is a smart WhatsApp bot that is very useful for helping you answer questions and provide accurate solutions in a short amount of time. Developed by *Tataa Dev [ Tataa Dev ]* , this bot uses the original source of Botcahx that is constantly updated by *Tataa Dev* to provide an easier and more enjoyable interactive experience.

With its broad ability to answer questions and provide solutions, *Tataa Bot* can assist you in various things such as searching for information about products or services, scheduling appointments, and much more. *Tataa Bot* can also provide accurate and quick answers so you no longer have to wait long to get the answers you need.

As a product developed and updated by *Tataa Dev, Tataa Bot* always receives the latest feature updates to provide better and more advanced services. With *Tataa Bot* , you don't have to worry about the quality of the service provided because this bot is always ready to provide the best solutions for WhatsApp users. So, what are you waiting for? Use "Tataa Bot" now and enjoy the ease and convenience of interacting with this smart bot on WhatsApp!`
  
 	conn.chatRead(m.chat)
	conn.sendMessage(m.chat, {
		react: {
			text: '🕒',
			key: m.key,
		}
	})

  let about = `${aboutID}\n\n${aboutEN}`

  let url = "https://telegra.ph/file/191255466221149ca48d0.jpg"

  conn.sendFile(m.chat, url, 'about.jpg', about, m)
}

handler.help = ['about', 'detile', 'aboutbot', 'tentang', 'detail', 'infobot']
handler.tags = ['info']
handler.command = /^(about|detile|aboutbot|tentang|detail|infobot)$/i
handler.register = true

module.exports = handler