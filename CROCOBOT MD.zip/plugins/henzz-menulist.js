let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu list'
let anu = `*Hai kak👋.* selamat datang di menulist bot *[ CROCObot ⁻ ᴹᵈ ]*. berikut ini adalah menulist nya

╭━━╼『 *M E N U  L I S T* 』
┃ ▸ .allmenu
┃ ▸ .menu-main
┃ ▸ .menu-downloader
┃ ▸ .menu-ai
┃ ▸ .menu-convert
┃ ▸ .menu-nsfw
┃ ▸ .menu-anime
┃ ▸ .menu-exp
┃ ▸ .menu-fun
┃ ▸ .menu-game
┃ ▸ .menu-sound
┃ ▸ .menu-group
┃ ▸ .menu-image
┃ ▸ .menu-info
┃ ▸ .menu-internet
┃ ▸ .menu-islami
┃ ▸ .menu-kerang
┃ ▸ .menu-maker
┃ ▸ .menu-owner
┃ ▸ .menu-suara
┃ ▸ .menu-premium
┃ ▸ .menu-quotes
┃ ▸ .menu-rpg
┃ ▸ .menu-stalk
┃ ▸ .menu-shortlink
┃ ▸ .menu
┃ ▸ .menu-tools
┃ ▸ .menu-anonymous
┃ ▸ .menu-audio
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  L I S T',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/7f59829e67ab1e49cf0bb.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
 conn.sendFile(m.chat, './mp3/menulist.mp3', '', null, m, true,)
}
handler.help = ['menulist']
handler.tags = ['menulist']
handler.command = /^(menulist)$/i

module.exports = handler