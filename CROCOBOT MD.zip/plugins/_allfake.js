let handler = {};
handler.all = async function (m) {
    let name = await conn.getName(m.sender);
    let pp = global.thumb;
    try {
        pp = await this.profilePictureUrl(m.sender, 'image');
    } catch (e) {
    } finally {
        global.rose = 'Rk-SyaiiPv';
        global.btc = 'Lio';
        global.doc = pickRandom(["application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.presentationml.presentation", "application/msword", "application/pdf"]);

        // Module 
        global.fetch = require('node-fetch');
        global.botdate = clockString();
        global.bochil = require('@bochilteam/scraper');

        const _uptime = process.uptime() * 1000;

        // Ini untuk command crator/owner
        global.kontak2 = [
            [owner[0], await conn.getName(owner[0] + '628563858981@s.whatsapp.net'), 'Clayza Aubert', 'https://clayzaaubert.my.id', true],
            [owner[0], await conn.getName(owner[0] + '628563858981@s.whatsapp.net'), 'Victoria Rosalind', 'https://clayzaaubert.my.id', true],
            [owner[0], await conn.getName(owner[0] + '628563858981@s.whatsapp.net'), 'Sazumi Henzz', 'https://clayzaaubert.my.id', true] // Kalo mau di tambah tinggal copy 1baris ini di tempel di bawahnya trs di edit dikit!
        ];

        // ucapan ini mah
        global.ucapan = ucapan();

        // pesan sementara
        global.ephemeral = '86400'; // 86400 = 24jam, kalo ingin di hilangkan ganti '86400' jadi 'null' atau ''

        // externalAdReply atau text with thumbnail. gatau bahasa Inggris? coba translate!
        global.adReply = {
            contextInfo: {
                forwardingScore: 9999,
                //isForwarded: false, // ini biar ada tulisannya diteruskan berkali-kali, jika ingin di hilangkan ganti true menjadi false, kalo isdorwarder di hapus // nya bakal jadi kirim pesan melalui iklan
                externalAdReply: { // Bagian ini sesuka kalian berkreasi :'v
                    showAdAttribution: true,
                    title: global.namebot,
                    body: global.author,
                    mediaUrl: global.sgc,
                    description: 'Victoria Rosalind Bot Whatsapp',
                    previewType: "PHOTO",
                    thumbnail: await (await fetch(global.thumb)).buffer(), //klo iconnya mau sesuai profile user ganti global.thumb jadi pp
                    sourceUrl: global.myweb,
                }
            }
        };
    }
}

module.exports = handler;

function ucapan() {
    const time = moment.tz('Asia/Jakarta').format('HH');
    let res = "malam Sek";
    if (time >= 4) {
        res = "Selamat pagi 🌅";
    }
    if (time > 10) {
        res = "Selamat siang kak ⛅";
    }
    if (time >= 15) {
        res = "selamat sore kak 🌄";
    }
    if (time >= 18) {
        res = "selamat malam kak 🌌";
    }
    return res;
}

function pickRandom(list) {
    return list[Math.floor(list.length * Math.random())];
}

function clockString() {
    const date = new Date();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const year = date.getFullYear();
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    const clockString = `Date: ${month}-${day}-${year}\nTime: ${hours}:${minutes}:${seconds}`;
    return clockString;
}
module.exports = handler;