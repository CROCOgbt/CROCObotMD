let gtts = require('node-gtts')
let fs = require('fs')
let path = require('path')
let { spawn } = require('child_process')
let axios = require('axios')

let handler = async (m, { conn, text }) => {
if (!text) return m.reply("🐱 Input Text")
try {

    const apiUrl = `https://api.azz.biz.id/api/alicia?q=${encodeURIComponent(
      m.quoted && m.quoted.text
        ? `AI : "${m.quoted.text}"\n\nUser : ${text}`
        : `User : ${text}`
    )}&user=${m.sender}&key=pelanpelanpaksupir`

    const response = await axios.get(apiUrl)
    const responseData = response.data.respon
    const err = "Mohon maaf, terdapat error pada fitur ini. Silahkan hubungi owner untuk informasi lebih lanjut."
  let lang = 'id'
  let txt = responseData

  let res
  try { res = await tts(txt, lang) }
  catch (e) {
    m.reply(e + '')
    res = await tts(err)
  } finally {
    conn.sendFile(m.chat, res, 'tts.opus', null, m, true)
  }
  } catch (error) {
    console.log(error)
    m.reply("An Error occurred")
  }
}
handler.help = ['aivoice <teks>']
handler.tags = ['tools']
handler.command = /^(aivoice)$/i
handler.limit = true
handler.premium = false
module.exports = handler

function tts(text, lang = 'id') {
  console.log(lang, text)
  return new Promise((resolve, reject) => {
    try {
      let tts = gtts(lang)
      let filePath = path.join(__dirname, '../tmp', (1 * new Date) + '.wav')
      tts.save(filePath, text, () => {
        resolve(fs.readFileSync(filePath))
        fs.unlinkSync(filePath)
      })
    } catch (e) { reject(e) }
  })
}