let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu fun'
let anu = `╭━━╼『 *M E N U  F U N* 』
┃ ▸ .putus (Ⓛ)
┃ ▸ .tolak *@tag* (Ⓛ)
┃ ▸ .ceksifat <nama>
┃ ▸ .dare (Ⓛ)
┃ ▸ .alay (Ⓛ)
┃ ▸ .namaninja <teks>
┃ ▸ .purba <teks>
┃ ▸ .suka *@tag*
┃ ▸ .top (Ⓛ)
┃ ▸ .artinama <name> (Ⓛ)
┃ ▸ .cekpacar (Ⓛ)
┃ ▸ .jadian (Ⓛ)
┃ ▸ .nama (Ⓛ)
┃ ▸ .taugasih (Ⓛ)
┃ ▸ .creepypasta
┃ ▸ .masadepan
┃ ▸ .meme (Ⓛ)
┃ ▸ .pick <jumlah> <teks>
┃ ▸ .send <nama_audio>
┃ ▸ .singkatan <teks (yntkts)>
┃ ▸ .zodiac *2002 02 25*
┃ ▸ .truth (Ⓛ)
┃ ▸ .ultah <tahun> <bulan> <tanggal>
┃ ▸ .umur
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  F U N',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/282fa77198a59903eeba3.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-fun']
handler.tags = ['menulist']
handler.command = /^(menu-fun)$/i

module.exports = handler