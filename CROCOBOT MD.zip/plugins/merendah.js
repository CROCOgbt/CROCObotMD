let {sticker5} = require ('../lib/sticker.js')
let handler = async (m, {conn}) => {
let P = 'https://telegra.ph/file/7032259163878edc5373a.jpg'
const key = await conn.sendMessage(m.chat, { audio: { url: './mp3/sepuh.opus' }, mimetype: 'audio/mpeg' }, { quoted: m });
let stiker = await sticker5(P, false, global.packname, global.author)
    if (stiker) return conn.sendFile(m.chat, stiker, 'Quotly.webp', '', key)
}
handler.customPrefix = /^sepuh|puh$/i
handler.command = new RegExp
module.exports = handler