let handler = async (m,{ conn }) => {
conn.reply(m.chat, `${pickRandomMotivasi()}`, m)
}
handler.customPrefix = /^nilai bang|nilai|saran|setor$/i
handler.command = new RegExp
module.exports = handler
function pickRandomMotivasi() {
    let motivasi = [
        "10 kak keren banget soalnya (≧▽≦)",
        "9 Sugoooi( ╹▽╹ )",
        "8 Jangan Nyerah Kak(◠‿◕)",
        "7 Cukup bagus, Jangan gampang menyerah yah"
    ];
    return motivasi[Math.floor(Math.random() * motivasi.length)];
}