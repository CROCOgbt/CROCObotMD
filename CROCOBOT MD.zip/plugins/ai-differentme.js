const axios = require('axios');
const fetch = require('node-fetch');
const fs = require('fs');
const FormData = require('form-data');
const uploadImage = require('../lib/uploadImage.js');

const handler = async (m, { conn, usedPrefix, command, text }) => {
  try {
    await m.reply('Wait...');

    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';
    if (!mime) throw 'Kirim/Balas Gambar dengan caption *differentme*';
    if (!text) throw 'Masukkan Style Nya';

    let media = await q.download();
    let url = await uploadImage(media);

    const queryParams = {
      style: text,
      json: false
    };

    const response = await fetch(url);
    const buffer = await response.buffer();

    const form = new FormData();
    form.append('file', buffer, {
      filename: 'image.jpg',
      contentType: 'image/jpeg',
      knownLength: buffer.length,
    });

    const { data } = await axios
            .request({
              baseURL: 'https://api.itsrose.life',
              url: '/image/differentMe',
              method: 'POST',
              params: {
                ...queryParams,
                apikey: global.rose,
              },
              data: form,
              responseType: 'arraybuffer',
            })
            .catch((e) => e.response.data);

          if (!data) {
            throw 'Failed to process image.';
          }

          const resultBuffer = Buffer.from(data, 'binary');
          return conn.sendFile(m.chat, resultBuffer, 'ppk.jpg', `STYLE: ${text.toUpperCase()}`, m);
  } catch (err) {
    console.error(err);
    throw err;
  }
};

handler.help = ['differentme'];
handler.tags = ['ai'];
handler.command = /^(differentme)$/i;
handler.premium = true;

module.exports = handler;