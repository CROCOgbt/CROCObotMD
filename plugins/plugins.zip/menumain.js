let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu main'
let anu = `*╭━━╼『 *M E N U  M A I N* 』
┃ ▸ .afk [alasan]
┃ ▸ .donasi (Ⓛ)
┃ ▸ .ceksn (Ⓛ)
┃ ▸ .logs
┃ ▸ .donasi (Ⓛ)
┃ ▸ .dashboard (Ⓛ)
┃ ▸ .dash (Ⓛ)
┃ ▸ .views (Ⓛ)
┃ ▸ .delete (Ⓛ)
┃ ▸ .delete
┃ ▸ .dering (Ⓛ)
┃ ▸ .edit
┃ ▸ .allmenu
┃ ▸ .help
┃ ▸ .buyprem [duration]
┃ ▸ .yt
┃ ▸ .youtube
┃ ▸ .medsos
┃ ▸ .infobot
┃ ▸ .calender <Creates a calendar with the given date.>
┃ ▸ .listpanel
┃ ▸ .checkapi
┃ ▸ .api
┃ ▸ .menfess <nomor|nama pengirim|pesan>
┃ ▸ .menfes <nomor|nama pengirim|pesan>
┃ ▸ .menu (Ⓛ)
┃ ▸ .mysaldo
┃ ▸ .os
┃ ▸ .tutorialrpg
┃ ▸ .rules
┃ ▸ .sewabot
┃ ▸ .store
┃ ▸ .addcategory <category name>
┃ ▸ .rcategory <category name>
┃ ▸ .addlist <list name> | <category name>
┃ ▸ .rlist <list name>
┃ ▸ .unreg <SERIAL NUMBER>
┃ ▸ .upsw
┃ ▸ .uptime (Ⓛ)
┃ ▸ @verify
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  M A I N',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/844cf3b7ba3deb7537b9a.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-main']
handler.tags = ['menulist']
handler.command = /^(menu-main)$/i

module.exports = handler