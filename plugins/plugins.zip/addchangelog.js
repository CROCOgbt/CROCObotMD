let moment = require('moment-timezone');

let jakartaTime = moment.tz('Asia/Jakarta');
let formattedDateTime = jakartaTime.format('ddd MMM D YYYY, k.mm a');
let handler = async(m, {conn, command, usedPrefix, text}) => {
  let fail = 'format salah, example: ' +usedPrefix+command+ ' take , title'
  global.db.data.changelong = global.db.data.changelong || []
  let changelog = global.db.data.changelong
  let split = text.split(', ')
  let time = formattedDateTime
  let take = split[0]
  let title = split[1]
  if (changelog.includes(title)) return m.reply('Judul tidak tersedia!\n\nAlasan: Sudah digunakan')
  if (!title) return m.reply(fail)
  let cttn = {
    'date': time,
    'take': take,
    'title': title
  }
  global.db.data.changelong.push(cttn)
  conn.reply(m.chat, `changelog berhasil dibuat☑️`, m, false, {
    contextInfo: {
      mentionedJid: conn.parseMention(text)
    }
  })
}

handler.help = ['addlogs <apa>']
handler.tags = ['owner']
handler.owner = true
handler.command = /^addlogs$/i

module.exports = handler