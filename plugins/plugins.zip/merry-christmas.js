let fs = require('fs')
let handler = async (m, { conn }) => {
let anu =`https://api.lolhuman.xyz/api/quotemaker2?apikey=thuthao&text=${pickRandom(global.merry)}&author=${conn.getName(m.sender)} 

`
conn.sendFile(m.chat, anu, '', wm, m)
conn.sendFile(m.chat, './mp3/natal.mp3', '', null, m, true, { type: "audioMessage", ptt: true, filelength: 999838483884 })
}
handler.help = ['uchristmas']
handler.tags = ['quotes']
handler.command = /^(uchristmas)$/i
module.exports = handler

function pickRandom(list) {
    return list[Math.floor(list.length * Math.random())]
}

global.merry = [
    "Selamat Hari Natal dan Tahun Baru. Damai senantiasa menyertaimu.",
    "Semoga Natal Anda menyenangkan dan Tahun Baru yang sejahtera.",
    "Selamat Natal dan Tahun Baru. Semoga damai dan sukacita menyertai kita semua.",
    "Libur akhirnya datang, jadi Selamat Natal dan Tahun Baru!",
    "Selamat Natal dengan banyak cinta dan Tahun Baru yang penuh kebahagiaan.",
    "Malam Natal yang indah dan momen Tahun Baru yang luar biasa.",
    "Salam terhangat di malam natal dan harapan terbaik untuk kebahagiaan di Tahun Baru)",
    "Ukir momen bahagia di perayaan Natal dan Tahun Baru.",
    "Selamat Natal dan Tahun Baru! Mari berharap awal yang baru akan membawa kebaikan bagi kita.",
    "Selamat Natal 25 Desember 2023 dan Tahun Baru 1 Januari 2024. Semoga kasihNya selalu ada di hati kita.",
   "Selamat Natal dan Tahun Baru! Selamat menikmati kehangatan dalam kebersamaan.",
   "Semoga cinta Tuhan selalu tercurah kepadamu di malam Natal ini dan harapan indah akan tercapai di Tahun Baru.",
    "Rayakan Keajaiban dan Kegembiraan Musim Perayaan. Selamat Natal dan Tahun Baru.",
    "Selamat Natal dan menyambut Tahun Baru . Aku berdoa yang terbaik untukmu di waktu liburan ini.",
    "Merry Christmas and Happy New Year! Semoga awal yang baru bisa membawa kebaikan untuk kita.",
    "Merry Christmas and Happy New Year! Semoga awal yang baru bisa membawa kebaikan untuk kita."
]