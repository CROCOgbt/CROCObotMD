var fetch = require('node-fetch');
var util = require('util');
var handler = async (m, {
 text, 
 usedPrefix, 
 command
 }) => {
if (!text) throw `Masukkan Nama character nya\n*Contoh:* .Charainfo Miku nakano`
await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }})
  var js = await fetch(`https://api.lolhuman.xyz/api/character?apikey=Akiraa&query=${text}`)
var json = await js.json()
try {
await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key }})
let hasil = ` *•Nama:* ${json.result.name.full}
*•description:* ${json.result.description}
${wm}`
const truei = conn.relayMessage(m.chat, {
  extendedTextMessage:{
                text: hasil, 
                contextInfo: {
                     externalAdReply: {
                        title: 'CHARA INFO',
                        body: 'Character Information',
                        mediaType: 1,
                        previewType: 0,
                        renderLargerThumbnail: true,
                        thumbnailUrl: json.result.image.large,
                        sourceUrl: ''
                    }
                }, mentions: [m.sender]
}}, {})
} catch (err) {
m.reply(util.format(js))
}}
handler.command = handler.help = ['charainfo'];
handler.tags = ['anime'];
handler.premium = false
module.exports = handler;