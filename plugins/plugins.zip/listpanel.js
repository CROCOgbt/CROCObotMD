let fs = require ('fs')
let handler = async (m, {conn}) => {
global.panel = `*[ ✅ PANEL BY AMURA MD ]*

_RAM 1 GB CPU RP 1.000 / BULAN_
_RAM 2 GB CPU RP 2.000 / BULAN_
_RAM 3 GB CPU RP 3.000 / BULAN_
_RAM 4 GB CPU 110% RP 4.000 / BULAN_
_RAM 5 GB CPU 140% RP 5.000 / BULAN_
_RAM 6 GB CPU 170% RP 6.000 / BULAN_
_RAM 7 GB CPU 180% RP 7.000 / BULAN_
_RAM 8 GB CPU 190% RP 8.000 / BULAN_
_RAM & CPU UNLIMITED RP IO.OOO/BULAN_

*[ ✅ KEUNTUNGAN PANEL ]*

• BISA BUAT RUN BOT NO RIBET
• WEBSITE/APK CLOSE BOT TETAP ON/JALAN
• GA BOROS KUOTA
• GA MENUHIN MEMORI
• UNTUK BIKIN BOT
• BOT MENJADI FAST RESPON
*===============================*
*[ OTHER ]*
- ADMIN MENYEDIAKAN:
- JASA EDIT SC ( SAMPE KE AKAR AKAR NYA)
- JASA ADD/FIX FITUR BOT 
- JASA BIKIN LOGO/BANNER 
- JASA GAMBAR 
- SC MD PRIVAT 500+ FITUR
- SC PUSHKONTAK
__________________________________________
🎴 *Minat??, contact Me 😋*
wa.me/84528059414
*===============================*`
await conn.sendMessage(m.chat, {
document: fs.readFileSync("./test.js"),
fileName: "OPEN PANEL BY AMURA",
mimetype: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
fileLength: 9999999,
pageCount: fpagedoc,
caption: panel,
contextInfo: {
externalAdReply: {  
title: 'LIST HARGA PANEL  MURAH, AMAN, TERPERCAYA ✅',
body: '',
thumbnailUrl: 'https://i3.wp.com/tmpfiles.org/dl/2364608/tmp.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true 
}}}, { quoted: m })
}
handler.command = handler.help = ["listpanel"]
handler.tags = ["main"]
module.exports = handler