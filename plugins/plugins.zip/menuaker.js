let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu maker'
let anu = `╭━━╼『 *M E N U  M A K E R* 』
┃ ▸ .amongus <text>
┃ ▸ .aovwall <text> (Ⓛ)
┃ ▸ .avatardota (Ⓛ)
┃ ▸ .blood
┃ ▸ .codwarzone <text>|<text> (Ⓛ)
┃ ▸ .goglesugest <text>|<text>|<text> (Ⓛ)
┃ ▸ .goldplaybutton <text> (Ⓛ)
┃ ▸ .greyscale (Ⓛ)
┃ ▸ .carbon <kode> (Ⓛ)
┃ ▸ .jadianime3 (Ⓛ)
┃ ▸ .jadizombie3 (Ⓛ)
┃ ▸ .underwater <teks> (Ⓛ)
┃ ▸ .idulfitri <text> (Ⓛ)
┃ ▸ .invoice <text>|<text> (Ⓛ)
┃ ▸ .joker <text> (Ⓛ)
┃ ▸ .juventusshirt <text>|<text> (Ⓛ)
┃ ▸ .ktp <text> (Ⓛ)
┃ ▸ .logogaming <text> (Ⓛ)
┃ ▸ .giraffe (Ⓛ)
┃ ▸ .magma (Ⓛ)
┃ ▸ .batman (Ⓛ)
┃ ▸ .marvelstudio2 (Ⓛ)
┃ ▸ .marvelstudio (Ⓛ)
┃ ▸ .avengers (Ⓛ)
┃ ▸ .ninjalogo (Ⓛ)
┃ ▸ .glitch3 (Ⓛ)
┃ ▸ .glitch2 (Ⓛ)
┃ ▸ .glitch (Ⓛ)
┃ ▸ .grafity (Ⓛ)
┃ ▸ .grafity2 (Ⓛ)
┃ ▸ .blood (Ⓛ)
┃ ▸ .jokerlogo (Ⓛ)
┃ ▸ .hallowen2 (Ⓛ)
┃ ▸ .space (Ⓛ)
┃ ▸ .thunder2 (Ⓛ)
┃ ▸ .1917 (Ⓛ)
┃ ▸ .3dstone (Ⓛ)
┃ ▸ .harrypotter (Ⓛ)
┃ ▸ .wolflogo (Ⓛ)
┃ ▸ .naturalleaves (Ⓛ)
┃ ▸ .blackpink (Ⓛ)
┃ ▸ .blackpink2 (Ⓛ)
┃ ▸ .dropwater (Ⓛ)
┃ ▸ .christmas (Ⓛ)
┃ ▸ .gradient (Ⓛ)
┃ ▸ .captainamerica (Ⓛ)
┃ ▸ .rusty (Ⓛ)
┃ ▸ .ice (Ⓛ)
┃ ▸ .honey (Ⓛ)
┃ ▸ .blood (Ⓛ)
┃ ▸ .koi (Ⓛ)
┃ ▸ .lava (Ⓛ)
┃ ▸ .bread (Ⓛ)
┃ ▸ .strawberry (Ⓛ)
┃ ▸ .toxic (Ⓛ)
┃ ▸ .wicker (Ⓛ)
┃ ▸ .fabric (Ⓛ)
┃ ▸ .pornhub (Ⓛ)
┃ ▸ .holograpic (Ⓛ)
┃ ▸ .deluxesilver (Ⓛ)
┃ ▸ .writing (Ⓛ)
┃ ▸ .engraved (Ⓛ)
┃ ▸ .gluetext (Ⓛ)
┃ ▸ .neondevil (Ⓛ)
┃ ▸ .skytext (Ⓛ)
┃ ▸ .vintage (Ⓛ)
┃ ▸ .multicolor (Ⓛ)
┃ ▸ .robot (Ⓛ)
┃ ▸ .scifi (Ⓛ)
┃ ▸ .artpapper (Ⓛ)
┃ ▸ .glossy (Ⓛ)
┃ ▸ .watercolor (Ⓛ)
┃ ▸ .neongreen (Ⓛ)
┃ ▸ .brokenglass (Ⓛ)
┃ ▸ .artpapper (Ⓛ)
┃ ▸ .valentine2 (Ⓛ)
┃ ▸ .neonlight (Ⓛ)
┃ ▸ .neongalaxy (Ⓛ)
┃ ▸ .magma (Ⓛ)
┃ ▸ .hallowen (Ⓛ)
┃ ▸ .valentine (Ⓛ)
┃ ▸ .masturbation  (Ⓟ)
┃ ▸ .mememaker <teks>|<teks> (Ⓛ)
┃ ▸ .nekosad
┃ ▸ .nulis (Ⓛ)
┃ ▸ .phcomments <text>|<text> (Ⓛ)
┃ ▸ .quotemaker <text> (Ⓛ)
┃ ▸ .raining
┃ ▸ .togif <reply|media>
┃ ▸ .tweet <comment>
┃ ▸ .ytcomment
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  M A K E R',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/cbdf38032d85ab25024c0.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-maker']
handler.tags = ['menulist']
handler.command = /^(menu-maker)$/i

module.exports = handler