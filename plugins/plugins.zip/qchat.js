const fetch = require('node-fetch');
const { sticker5 } = require('../lib/sticker.js');
const uploadImage = require('../lib/uploadImage.js');

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
  if (!text) throw `*Example*: ${usedPrefix + command} bang syaii`;
  if (args[0] && args[0].includes('|')) {
    if (!args[1]) throw `*Example*: ${usedPrefix + command} bang syaii`;
    let kata = args[1];
    let q = m.quoted || m;
    let mime = (q.msg || q).mimetype || '';
    let media = await q.download();
    let url = await uploadImage(media);
    let name = conn.getName(m.sender);
    const pp = await conn.profilePictureUrl(m.sender, 'image').catch((_) => "https://telegra.ph/file/1ecdb5a0aee62ef17d7fc.jpg");
    const fetchResult = await fetch(`https://api.lolhuman.xyz/api/shortlink?apikey=Akiraa&url=${encodeURIComponent(pp)}`);
    const json = await fetchResult.json();
    const poto = json.result;
    let P = `https://xzn.wtf/api/qc?text=${encodeURIComponent(text)}&username=${name}&avatar=${poto}&media=${url}&apikey=about`;
    let stiker = await sticker5(P, false, global.packname, global.author);
    if (stiker) return conn.sendFile(m.chat, stiker, 'Quotly.webp', '', m);
  } else {
    let name = conn.getName(m.sender);
    const pp = await conn.profilePictureUrl(m.sender, 'image').catch((_) => "https://telegra.ph/file/1ecdb5a0aee62ef17d7fc.jpg");
    const fetchResult = await fetch(`https://api.lolhuman.xyz/api/shortlink?apikey=Akiraa&url=${encodeURIComponent(pp)}`);
    const json = await fetchResult.json();
    const poto = json.result;
    let url = `https://xzn.wtf/api/qc?text=${encodeURIComponent(text)}&username=${name}&avatar=${poto}&apikey=about`;
    let stiker = await sticker5(url, false, global.packname, global.author);
    if (stiker) return conn.sendFile(m.chat, stiker, 'Quotly.webp', '', m);
  }
};

handler.help = ['qchat'];
handler.tags = ['image'];
handler.command = /^(qchat)$/i;
handler.limit = true
handler.premium = true
module.exports = handler;