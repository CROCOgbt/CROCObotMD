let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu quotes'
let anu = `╭━━╼『 *M E N U  Q U O T E S* 』
┃ ▸ .galau
┃ ▸ .newyears
┃ ▸ .bucin (Ⓛ)
┃ ▸ .uchristmas
┃ ▸ .motivasi
┃ ▸ .pantun
┃ ▸ .bacot
┃ ▸ .hacker
┃ ▸ .quotes (Ⓛ)
┃ ▸ .videoquotes (Ⓛ)
┃ ▸ .videogalau (Ⓛ)
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  Q U O T E S',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/247c06de081146bfe3cfa.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-quotes']
handler.tags = ['menulist']
handler.command = /^(menu-quotes)$/i

module.exports = handler