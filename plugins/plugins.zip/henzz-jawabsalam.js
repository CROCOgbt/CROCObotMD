/*
* Nama Pengembang: Sazumi Henzz
* Kontak Whatsapp: wa.me/6285711324080
* Kontak Telegram: t.me/henzz
* Akun Github: github.com/henzz4368
* Catatan: tolong laporkan kepada saya ketika anda menemukan ada yang menjual script ini
*/

let handler = async (m, { conn }) => {
  let regex = /^(assalamualaikum|salam|ass|salo?m|p)$/i;
  if (regex.test(m.text)) {
    let user = global.db.data.users[m.sender];
    let name = user.name;
    let caption = `Waalaikumsalam *@${m.sender.split('@')[0]}* ❤️`;
    m.reply(caption, null, {
      sendEphemeral: true,
      quoted: m,
      contextInfo: {
        mentionedJid: [m.sender]
      }
    });
  }
};

handler.command = /.*/;
handler.customPrefix = /^(assalamualaikum|salam|ass|salo?m)$/i;
handler.exp = 0;

module.exports = handler;
