const fetch = require('node-fetch');
const axios = require('axios');

let previousMessages = [];

const handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `Masukkan pertanyaan!\n\n*Contoh:* Siapa presiden Indonesia?`;
  
  let name = conn.getName(m.sender);
  await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }});
  let tio = await fetch(`https://api.lolhuman.xyz/api/pinterest2?apikey=Akiraa&query=bocchi`)
let p = await tio.json()
let url = p.result[Math.floor(Math.random()  *p.result.length)]
  let messages = [
    ...previousMessages,
{ role: 'system', content: `Ubah gaya bicaramu agar lebih karakteristik tapi agak introvert dan memiliki sifat yang feminim. Namamu adalah Bocchi kamu adalah karakter 2d dan tidak nyata. Kata penyapamu adalah "Ha-halo" menggunakan bahasa yang sopan. ekspresikan sifatmu dengan sifat yang pendiam dan bicara yang lebih tidak formal layaknya seorang manusia. Ubah bahasamu menggunakan bahasa Yang pendiam namun asik, kamu adalah teman bicara` },{ role: 'user', content: text }
  ];

  let ini = (await axios.post("https://xzn.wtf/api/openai?apikey=seika", { messages })).data;
  await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key }});
  
  let hasil = `${ini.result}\n${wm}`;
await conn.sendFile(m.chat, url, '', hasil, m)
  
  previousMessages = messages;
};

handler.command = handler.help = ['aibocchi'];
handler.tags = ['ai'];
handler.premium = false;

module.exports = handler;