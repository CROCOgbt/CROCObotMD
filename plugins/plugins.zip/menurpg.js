let fs = require('fs')
let handler = async (m, { conn }) => {
let teks = 'menu rpg'
let anu = `╭━━╼『 *M E N U  R P G* 』
┃ ▸ .bertarung @user
┃ ▸ .codeshortlink (Ⓛ)
┃ ▸ .bertani
┃ ▸ .fightcentaur (Ⓛ)
┃ ▸ .dailymisi
┃ ▸ .leaderboard <jumlah user>
┃ ▸ .ngegay
┃ ▸ .polisi2
┃ ▸ .adventure (Ⓛ)
┃ ▸ .atm <jumlah> (Ⓛ)
┃ ▸ .atmall (Ⓛ)
┃ ▸ .bank
┃ ▸ .dompet
┃ ▸ .dompet @user
┃ ▸ .bank
┃ ▸ .bansos
┃ ▸ .bansos2 *@friend*
┃ ▸ .berburu
┃ ▸ .berdagang *@tag* (Ⓛ)
┃ ▸ .berkebon (Ⓛ)
┃ ▸ .berlatih (Ⓛ)
┃ ▸ .bosbattle
┃ ▸ .collect
┃ ▸ .cd
┃ ▸ .cooldown
┃ ▸ .craft
┃ ▸ .dailymisi
┃ ▸ .duel
┃ ▸ .dungeon
┃ ▸ .feed [pet type]
┃ ▸ .fishop <sell|buy>  <item> <args>
┃ ▸ .tokoikan <sell|buy> <item> <args>
┃ ▸ .gaji
┃ ▸ .gajian
┃ ▸ .heal (Ⓛ)
┃ ▸ .heal
┃ ▸ .inv (Ⓛ)
┃ ▸ .judi <jumlah>
┃ ▸ .kandang
┃ ▸ .Karung
┃ ▸ .kerja
┃ ▸ .work
┃ ▸ .kerja2
┃ ▸ .work2
┃ ▸ .kotakikan
┃ ▸ .kolam
┃ ▸ .kolamikan
┃ ▸ .eat
┃ ▸ .makan
┃ ▸ .masak <masakan> <args>
┃ ▸ .cook <masakan> <args>
┃ ▸ .membunuh <@tag> (Ⓛ)
┃ ▸ .meracik <type> (Ⓛ)
┃ ▸ .merampok <@tag> (Ⓛ)
┃ ▸ .nambang (Ⓛ)
┃ ▸ .mining (Ⓛ)
┃ ▸ .mulung (Ⓛ)
┃ ▸ .nabung <jumlah>
┃ ▸ .narik <jumlah>
┃ ▸ .nebang (Ⓛ)
┃ ▸ .ngewe  (Ⓟ)
┃ ▸ .nguli
┃ ▸ .open <crate>
┃ ▸ .gacha <crate>
┃ ▸ .pasar <jual> <args>
┃ ▸ .polisi
┃ ▸ .pull <jumlah> (Ⓛ)
┃ ▸ .pullall (Ⓛ)
┃ ▸ .ramuan [pet type] (Ⓛ)
┃ ▸ .rob
┃ ▸ .polisi
┃ ▸ .sawer
┃ ▸ .selectskill *<type>*
┃ ▸ .shop <sell|buy> <args> (Ⓛ)
┃ ▸ .transfer <Args>
┃ ▸ .use <item> <jumlah>
┃ ▸ .level
╰━━━━━━━━╼
`
  await conn.sendMessage(m.chat, {
text: anu,
contextInfo: {
externalAdReply: {  
title: 'M E N U  R P G',
body: namebot,
thumbnailUrl: 'https://telegra.ph/file/565a53bc8f9c5ddfe32ba.jpg',
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
}
handler.help = ['menu-rpg']
handler.tags = ['menulist']
handler.command = /^(menu-rpg)$/i

module.exports = handler