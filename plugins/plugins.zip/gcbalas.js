let fs = require('fs');
let fetch = require('node-fetch');

let handler = async (m, { conn, text, usedPrefix: _p }) => {
  let [number, pesan] = text.split('|');

  if (!number) return conn.reply(m.chat, 'Silahkan masukan id grup yang akan dikirim', m);
  if (!pesan) return conn.reply(m.chat, 'Silahkan masukan pesannya', m);
  if (pesan.length > 500) return conn.reply(m.chat, 'Teks terlalu panjang! Batas karakter adalah 500.', m);

  let korban = number;
  let spam1 = `「 EMAIL 」\n\nDari: Owner\nKe: ${korban}\nPesan: ${pesan}\n\n${global.wm}`;

  await conn.relayMessage(korban, {
    extendedTextMessage: {
      text: spam1,
      contextInfo: {
        externalAdReply: {
          title: 'PESAN DARI OWNER',
          body: '💌 Ada pesan nih dari owner',
          mediaType: 1,
          previewType: 1,
          renderLargerThumbnail: true,
          thumbnailUrl: 'https://telegra.ph/file/d6202dfdc68e72b669631.jpg',
          sourceUrl: ''
        }
      }
    }
  });

  let logs = `[!] Berhasil mengirim pesan WhatsApp ke grup dengan ID ${number}`;
  conn.reply(m.chat, logs, m);
};

handler.command = /^(gcpesan|gcbalas)$/i;
handler.owner = true;
handler.premium = false;
handler.group = false;
handler.private = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;
handler.limit = false;

module.exports = handler;