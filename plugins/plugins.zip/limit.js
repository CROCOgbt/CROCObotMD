let handler = async (m) => {
    let who
    if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.sender
    else who = m.sender
 let name = await conn.getName(m.sender)
   const fpayment = {
"key": {
"remoteJid": "0@s.whatsapp.net",
"fromMe": false,
"id": "BAE595C600522C9C",
"participant": "0@s.whatsapp.net"
},
"message": {
"requestPaymentMessage": {
"currencyCodeIso4217": "USD",
"amount1000": 100000000,
"requestFrom": "0@s.whatsapp.net",
"noteMessage": {
"extendedTextMessage": {
"text": "Halo bang:" + name
}
},
"expiryTimestamp": 100000000000,
"amount": {
"value": 100000000000,
"offset": 1000000000000,
"currencyCode": "USD"
}
}
}
}
conn.reply(m.chat,`${global.db.data.users[who].limit} Limit Tersisaಥ_ಥ`, fpayment)

}
handler.help = ['limit [@user]']
handler.tags = ['xp']
handler.command = /^(limit)$/i
module.exports = handler