let { mediafiredl } = require("@bochilteam/scraper");
let handler = async (m, { conn }) => {
  await conn.reply(m.chat, `Tapi amura gak bisa nyanyi lah om, tapi boleh deh special untuk om😆`, m);
	let lol = [
		"https://www.mediafire.com/file/3heatlwcwgzyy9x/6.mp3/file",
		"https://www.mediafire.com/file/p1uc9qcye0rxexj/3.mp3/file",
		"https://www.mediafire.com/file/eg5zng5ylkdltv2/4.mp3/file",
		"https://www.mediafire.com/file/0yyk2i8oinngy8z/2.mp3/file",
		"https://www.mediafire.com/file/7q1ju9lchf7kv0c/5.mp3/file",
		"https://www.mediafire.com/file/l53uk7vvo2loc11/1.mp3/file",
		"https://www.mediafire.com/file/7cbhgjntsc49pry/sing.mp3/file",
		"https://www.mediafire.com/file/hzs9ogpadgd7ndf/10.mp3/file",
		"https://www.mediafire.com/file/i1lwkhh3pvv6olx/8.mp3/file",
		"https://www.mediafire.com/file/5lirxzrzzfahj0r/9.mp3/file",
		"https://www.mediafire.com/file/321g1y8evjrh1by/AUD-20231130-WA0918.mp3/file",
	];
	let anu = lol[Math.floor(Math.random() * lol.length)];
	
	let lol2 = [
`${anu}`, 
"https://www.mediafire.com/file/3heatlwcwgzyy9x/6.mp3/file",
"https://www.mediafire.com/file/p1uc9qcye0rxexj/3.mp3/file",
"https://www.mediafire.com/file/eg5zng5ylkdltv2/4.mp3/file",
"https://www.mediafire.com/file/0yyk2i8oinngy8z/2.mp3/file",
"https://www.mediafire.com/file/7q1ju9lchf7kv0c/5.mp3/file",
"https://www.mediafire.com/file/l53uk7vvo2loc11/1.mp3/file",
"https://www.mediafire.com/file/7cbhgjntsc49pry/sing.mp3/file",
"https://www.mediafire.com/file/hzs9ogpadgd7ndf/10.mp3/file",
"https://www.mediafire.com/file/i1lwkhh3pvv6olx/8.mp3/file",
"https://www.mediafire.com/file/5lirxzrzzfahj0r/9.mp3/file",
"https://www.mediafire.com/file/321g1y8evjrh1by/AUD-20231130-WA0918.mp3/file",
]

let anu2 = lol2[Math.floor(Math.random() * lol2.length)];
	
	let res = await mediafiredl(anu2);
	let { url, url2, filename, ext, aploud, filesize, filesizeH } = res;
	await conn.sendFile(m.chat, url, filename, '```Success...\nDont forget to donate```', m, {
		asDocument: false,
	});
};

handler.customPrefix = /^song|nyanyi$/i;
handler.command = new RegExp();

module.exports = handler